---
Name: ClipAndMerge
URL: http://www.github.com/apeltzer/ClipAndMerge
Description: >
  adapter clipping and read merging in ancient DNA analysis
---

An application to clip adapter sequences and merge reads in ancient DNA analysis. Note, that versions < 1.7.8 use the basename of the file path to distinguish samples, whereas newer versions produce logfiles with a sample identifer that gets parsed by MultiQC.
