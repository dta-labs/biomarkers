---
Name: EigenStratDatabaseTools
URL: https://github.com/TCLamnidis/EigenStratDatabaseTools
Description: >
  A set of tools to compare and manipulate the contents of EingenStrat databases, and to calculate SNP coverage statistics in such databases.
---

A set of tools to compare and manipulate the contents of EingenStrat databases, and to calculate SNP coverage statistics in such databases.
