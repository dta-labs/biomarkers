---
Name: KAT
URL: https://github.com/TGAC/KAT
Description: >
  The K-mer Analysis Toolkit (KAT) contains a number of tools that analyse and compare K-mer spectra.
---

The KAT multiqc module interprets output from KAT distribution analysis json files, which typically contain information such as estimated genome size and heterozygosity rates from your k-mer spectra.
