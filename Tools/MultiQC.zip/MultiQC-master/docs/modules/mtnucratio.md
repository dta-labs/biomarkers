---
Name: MTNucRatio
URL: http://www.github.com/apeltzer/MTNucRatioCalculator
Description: >
  A simple tool to compute mitochondrial to nuclear genome ratios.
---

A method to compute mitochondrial to nuclear reads ratios for NGS data.
