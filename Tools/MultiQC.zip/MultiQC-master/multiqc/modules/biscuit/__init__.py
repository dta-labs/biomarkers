from __future__ import absolute_import

from .biscuit import MultiqcModule
