from __future__ import absolute_import

from .conpair import MultiqcModule
