from __future__ import absolute_import

from .deeptools import MultiqcModule
