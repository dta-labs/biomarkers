from __future__ import absolute_import

from .fgbio import MultiqcModule
