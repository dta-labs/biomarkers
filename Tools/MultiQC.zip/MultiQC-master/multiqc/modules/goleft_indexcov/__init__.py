from __future__ import absolute_import

from .goleft_indexcov import MultiqcModule
