from __future__ import absolute_import
from .hops import MultiqcModule
