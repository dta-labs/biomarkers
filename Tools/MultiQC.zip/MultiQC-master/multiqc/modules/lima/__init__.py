from __future__ import absolute_import
from .lima import MultiqcModule
