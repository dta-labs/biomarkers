from __future__ import absolute_import
from .pychopper import MultiqcModule
