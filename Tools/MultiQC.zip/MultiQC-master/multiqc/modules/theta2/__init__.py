from __future__ import absolute_import

from .theta2 import MultiqcModule
