The user manual is available in http://www.ncbi.nlm.nih.gov/books/NBK279690
Release notes are available in http://www.ncbi.nlm.nih.gov/books/NBK131777
